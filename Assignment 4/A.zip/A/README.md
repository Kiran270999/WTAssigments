#Node JS Static Website

Run `node index.js`